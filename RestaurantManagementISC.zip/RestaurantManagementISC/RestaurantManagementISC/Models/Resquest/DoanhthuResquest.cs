﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantManagementISC.Models.Resquest
{
    public class DoanhthuResquest
    {
        public DateTime dateFrom { get; set; }
        public DateTime dateTo { get; set; }
    }
}
