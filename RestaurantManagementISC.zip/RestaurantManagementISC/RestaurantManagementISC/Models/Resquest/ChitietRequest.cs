﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantManagementISC.Models.VewModels
{
    public class ChitietRequest
    {
        public int idHoaDon { get; set; }
        public int idMonAn { get; set; }
    }
}
